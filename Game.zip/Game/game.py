import engine_module  # Assuming this is the module where Engine is defined
import time
import ctypes  # For using SDL functions directly if necessary
import argparse

def game_win(scene):
    ret = False
    for contact in scene.GetBoyContacts():
        if contact.GetTypeName() == "BoyDoor":
            ret = True
            break

    if not ret:
        return False

    ret = False
    for contact in scene.GetGirlContacts():
        if contact.GetTypeName() == "GirlDoor":
            ret = True
            break
    return ret

def game_lose(scene):
    for contact in scene.GetBoyContacts():
        if contact.GetTypeName() == "GreenWater" or contact.GetTypeName() == "BlueWater":
            return True

    for contact in scene.GetGirlContacts():
        if contact.GetTypeName() == "GreenWater" or contact.GetTypeName() == "RedWater":
            return True
    return False

def collect_diamond(scene):
    ret = 0
    for contact in scene.GetBoyContacts():
        if contact.GetTypeName() == "RedDiamond" and contact.IsRenderable():
            contact.SetRenderable(0)
            ret += 1

    for contact in scene.GetGirlContacts():
        if contact.GetTypeName() == "BlueDiamond" and contact.IsRenderable():
            contact.SetRenderable(0)
            ret += 1
    return ret

def turn_on_switch(scene):
    for contact in scene.GetBoyContacts():
        if contact.GetTypeName() == "RedSwitch" or contact.GetTypeName() == "WhiteSwitch":
            link = contact.GetChildGameEntityAtIdx(0)
            link = engine_module.ToControllable(link)
            link.on = True

    for contact in scene.GetGirlContacts():
        if contact.GetTypeName() == "RedSwitch" or contact.GetTypeName() == "WhiteSwitch":
            link = contact.GetChildGameEntityAtIdx(0)
            link = engine_module.ToControllable(link)
            link.on = True

def turn_on_switchable_object(scene):
    for entity in scene.GetAllEntities():
        if (entity.GetTypeName() == "Barrier" or entity.GetTypeName() == "Elevator"):
            entity = engine_module.ToControllable(entity)
            if entity.on and entity.currentY > 0.5:
                entity.SetSpeed(0, -3)
            elif abs(entity.currentY - entity.originY) > 0.0001:
                entity.SetSpeed(0, 3)
            else:
                entity.SetSpeed(0, 0)

def run_level(engine, level_file, target_fps):
    # Load the level
    engine.LoadScene(level_file)

    # Initialize variables for game loop
    delta_time = 1.0 / target_fps
    frame_elapsed = 0
    point = 0

    # Level-specific game loop
    while True:
        frame_start = time.time()

        engine.Input(delta_time)
        engine.Update(delta_time)
        engine.Render()

        if game_win(engine.GetScene()):
            print(f"Level completed: {level_file}")
            print(f"Points: {point}")
            return point, True  # Return points and success status
        if game_lose(engine.GetScene()):
            print(f"Level failed: {level_file}")
            print(f"Points: {point}")
            return point, False  # Return points and fail status

        turn_on_switch(engine.GetScene())
        turn_on_switchable_object(engine.GetScene())

        point += collect_diamond(engine.GetScene())

        frame_end = time.time()
        elapsed_time = frame_end - frame_start
        frame_elapsed += 1

        if elapsed_time < delta_time:
            time.sleep(delta_time - elapsed_time)

def run_game_loop(levels, target_fps):
    engine = engine_module.Engine()
    total_points = 0

    for level_file in levels:
        points, success = run_level(engine, level_file, target_fps)
        total_points += points
        if not success:
            print(f"Game over! Total points: {total_points}")
            break

    if success:
        print(f"Congratulations! You've completed all levels. Total points: {total_points}")

    engine.ShutDown()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run a series of game levels.")
    parser.add_argument('levels', metavar='Level', type=str, nargs='+',
                        help='A list of level JSON files to be loaded')
    parser.add_argument('--fps', type=int, default=60,
                        help='Target frames per second (default: 60)')
    args = parser.parse_args()

    run_game_loop(args.levels, args.fps)
