#!/bin/sh
python3 game.py level3.json level2.json level1.json
